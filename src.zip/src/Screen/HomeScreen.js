// import React from 'react';
// import { View, FlatList, StyleSheet } from 'react-native';
// import ProductItem from '../components/ProductItem';

// const PRODUCTS = [
//   {
//     id: 1,
//     Image: require('../assents/tshirt.png'),
//     name: 'T-shirt',
//     type: "Men's Clothing",
//     description: 'A comfortable and stylish t-shirt made from premium cotton.',
//     price: 19.99,
//     count: 0, // Initialize count for tracking quantity
//   },
//   {
//     id: 2,
//     Image: require('../assents/jewelry.png'),
//     name: 'Gold Necklace',
//     type: 'Jewelery',
//     description: 'Elegant 18K gold necklace perfect for special occasions.',
//     price: 299.99,
//     count: 0,
//   },
//   {
//     id: 3,
//     Image: require('../assents/user-interface.png'),
//     name: 'Smartphone',
//     type: 'Electronics',
//     description: 'A cutting-edge smartphone with a stunning display and fast performance.',
//     price: 899.99,
//     count: 0,
//   },
//   {
//     id: 4,
//     Image: require('../assents/summer.png'),
//     name: 'Summer Dress',
//     type: "Women's Clothing",
//     description: 'A light and airy summer dress with a floral print.',
//     price: 39.99,
//     count: 0,
//   },
// ];

// const HomeScreen = () => {
//     const [products, setProducts] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//   return (
//     <View style={styles.container}>
//       <FlatList
//         data={PRODUCTS}
//         keyExtractor={(item) => item.id.toString()}
//         renderItem={({ item }) => <ProductItem product={item} />}
//       />
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 10,
//     backgroundColor: '#f5f5f5',
//   },
// });

// export default HomeScreen;




import React, { useEffect, useState } from 'react';
import { View, FlatList, StyleSheet, Text, ActivityIndicator } from 'react-native';
import ProductItem from '../components/ProductItem';

const HomeScreen = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch data from the API
    const fetchProducts = async () => {
      try {
        const response = await fetch('https://fakestoreapi.com/products');
        const data = await response.json();
        setProducts(data);  // Store data in the state
        setLoading(false);   // Set loading to false once data is fetched
      } catch (err) {
        setError('Failed to load products');
        setLoading(false);  // Set loading to false even on error
      }
    };

    fetchProducts();
  }, []);

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#0000ff" />
        <Text>Loading products...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.container}>
        <Text>{error}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={products}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => <ProductItem product={item} />}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default HomeScreen;
