// import { createSlice } from '@reduxjs/toolkit';

// const initialState = {
//   cart: {},
//   totalCount: 0,
// };

// const cartSlice = createSlice({
//   name: 'cart',
//   initialState,
//   reducers: {
//     addToCart: (state, action) => {
//       const productId = action.payload;
//       if (state.cart[productId]) {
//         state.cart[productId]++;
//       } else {
//         state.cart[productId] = 1;
//       }
//       state.totalCount++;
//     },
//     removeFromCart: (state, action) => {
//       const productId = action.payload;
//       if (state.cart[productId]) {
//         state.cart[productId]--;
//         state.totalCount--;
//         if (state.cart[productId] === 0) {
//           delete state.cart[productId];
//         }
//       }
//     },
//   },
// });

// export const { addToCart, removeFromCart } = cartSlice.actions;
// export default cartSlice.reducer;




// import { createSlice } from '@reduxjs/toolkit';

// const cartSlice = createSlice({
//   name: 'cart',
//   initialState: {
//     items: {}, // Store quantities keyed by product ID
//     totalCount: 0, // Total quantity of all products
//   },
//   reducers: {
//     addToCart: (state, action) => {
//       const productId = action.payload;
//       state.items[productId] = (state.items[productId] || 0) + 1;
//       state.totalCount += 1;
//     },
//     removeFromCart: (state, action) => {
//       const productId = action.payload;
//       if (state.items[productId]) {
//         state.items[productId] -= 1;
//         state.totalCount -= 1;
//         if (state.items[productId] === 0) {
//           delete state.items[productId];
//         }
//       }
//     },
//   },
// });

// export const { addToCart, removeFromCart } = cartSlice.actions;
// export default cartSlice.reducer;



import { createSlice } from '@reduxjs/toolkit';

const cartSlice = createSlice({
  name: 'cart',
  initialState: {
    cart: {}, // { productId: quantity }
    totalCount: 0,
  },
  reducers: {
    addToCart: (state, action) => {
      const id = action.payload;
      if (state.cart[id]) {
        state.cart[id] += 1;
      } else {
        state.cart[id] = 1;
      }
      state.totalCount += 1;
    },
    removeFromCart: (state, action) => {
      const id = action.payload;
      if (state.cart[id]) {
        state.totalCount -= 1;
        state.cart[id] -= 1;
        if (state.cart[id] === 0) {
          delete state.cart[id];
        }
      }
    },
  },
});

export const { addToCart, removeFromCart } = cartSlice.actions;
export default cartSlice.reducer;
